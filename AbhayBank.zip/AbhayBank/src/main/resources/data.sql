insert into User (user_id,user_fname,user_lname,account_number,user_email,user_pass,user_mobile) values (1,'Aadeesh','Jain','1234567','aadeeshjain.91a@yahoo.com','abcd@234','9876543212');
insert into User (user_id,user_fname,user_lname,account_number,user_email,user_pass,user_mobile) values (2,'Andrew','Jate','1234568','andrewjate.df@yahoo.com','andrew@9','9876547542');
insert into User (user_id,user_fname,user_lname,account_number,user_email,user_pass,user_mobile) values (3,'John','Deed','1234569','john619.91a@yahoo.com','john@3113','9876544444');
insert into User (user_id,user_fname,user_lname,account_number,user_email,user_pass,user_mobile) values (4,'Peter','Parker','1234570','peter.parker@gmail.com','pet_er@9','9871117542');
